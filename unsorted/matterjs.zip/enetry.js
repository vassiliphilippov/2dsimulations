/**
* The `Energy` module [//todo: to be described].
*
* @class Energy
*/

var Energy = {};

(function() {

//energy conservation in physics engine

})();
