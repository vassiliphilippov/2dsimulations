/**
* The `Attractor` module [//todo: to be described].
*
* @class Attractor
*/

var Attractor = {};

(function() {

//charges
//different forces

})();
